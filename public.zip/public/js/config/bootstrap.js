var config = {
    'api_url': "http://waltgroupq.cluster003.ovh.net/public"
}

var in_audit = false;
